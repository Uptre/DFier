#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os

def main():
    abi_dir = "//home/fabric/DFuzzer/sFuzzData_classfied/freezing_ether_74/verified_contract_abis/"
    bin_dir = "/home/fabric/DFuzzer/sFuzzData_classfied/freezing_ether_74/verified_contract_bins/"
    sol_dir = "/home/fabric/DFuzzer/sFuzzData_classfied/freezing_ether_74/verified_contract_sols/"
    files = os.walk(sol_dir)
    f = open("./out.txt", "a+")
    for _, _, file_list in files:
        for file in file_list:
            file_name = file.split(".")[0]
            print("file: ", file, file=f) 
            abi_com = "solc -o " + abi_dir + " --abi " + sol_dir + file 
            bin_com = "solc -o " + bin_dir + " --bin-runtime " + sol_dir + file
            print("abi_com: ", abi_com, file=f)
            print("bin_com: ", bin_com, file=f)
            os.system(abi_com)
            os.system(bin_com)
            Cur_abi_file_path = abi_dir + file_name + ".abi"
            Cur_bin_file_path = bin_dir + file_name + ".bin-runtime"
            #recompile_com_abi = "r\'" + Cur_abi_file_path + "\'"
            #recompile_com_bin = "r\'" + Cur_bin_file_path + "\'"
            print("recompile_com_abi", Cur_abi_file_path)
            print("recompile_com_bin", Cur_bin_file_path)
            if os.path.exists(Cur_abi_file_path):
                print("succeed to generate abi for file: ", file,  file=f)
            else:
                print("failed to generate abi for file: ", file,   file=f)
            if os.path.exists(Cur_bin_file_path):
                print("succeed to generate bin for file: ", file,   file=f)
            else:
                print("failed to generate bin for file: ", file,  file=f)
    f.close()


if __name__ == '__main__':
    main()